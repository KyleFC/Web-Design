var groceries = ['eggs', 'milk', 'creamer', 'cereal'];

for(let i=0; i<groceries.length; i++)
{
    let par = document.createElement("p");
    par.innerText = groceries[i];
    par.className = "red";
    par.addEventListener("click", changeStatus);
    document.getElementById("main-container").appendChild(par);
}

function changeStatus (e)
{
    if(e.target.className == "red")
    {
        e.target.className = "blue";
    }
    else
    {
        e.target.className = "red";
    }
}

let inp = document.getElementById("grocery-input");
inp.addEventListener("focus", function() 
{
    inp.style.borderColor = "lightblue";
})
inp.addEventListener("blur", function()
{
    inp.style.borderColor = "#ccc";
})

var gForm = document.getElementById("grocery-form");
gForm.addEventListener("submit", function(e)
{
    e.preventDefault();
    var p = document.createElement("p");
    p.innerText = e.target.grocery.value
    p.className = "red";
    p.addEventListener("click", changeStatus);
    document.getElementById("main-container").appendChild(p);
    inp.value = "";
})
window.addEventListener("keyup", function(e)
{
    console.log(e.key);
    if(e.key == "1")
    {
        alert("You pressed 1");
    }
})
